<?php
// actualizar_carrito.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_producto = $_POST['id_producto'];
    $action = $_POST['action'];

    // Aquí deberías tener funciones o clases que manejen el carrito y la cantidad
    // Por ejemplo, podrías tener una función para incrementar la cantidad
    // y otra para decrementarla.

    if ($action == "incrementar") {
        // Función para incrementar la cantidad del producto en el carrito
        incrementarCantidadEnCarrito($id_producto);
    } elseif ($action == "decrementar") {
        // Función para decrementar la cantidad del producto en el carrito
        decrementarCantidadEnCarrito($id_producto);
    }

    // Redirigir de nuevo a la página del carrito o donde sea necesario
    header("Location: carrito.php");
    exit();
}
?>
