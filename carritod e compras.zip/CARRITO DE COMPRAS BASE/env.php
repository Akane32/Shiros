; <?php exit; ?>
MYSQL_DATABASE_NAME = "shiros"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""