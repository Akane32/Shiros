<?php
header("Location: tienda.php");
